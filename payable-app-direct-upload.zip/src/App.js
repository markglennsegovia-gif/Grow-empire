import React, { useState } from "react";

export default function App() {
  const [paid, setPaid] = useState(false);

  return (
    <div style={{ fontFamily: "Arial", textAlign: "center", marginTop: "50px" }}>
      <h1>Welcome to Payable App</h1>
      {!paid ? (
        <div>
          <p>This content is locked. Please pay to unlock.</p>
          <button onClick={() => setPaid(true)}>Simulate Payment</button>
        </div>
      ) : (
        <div>
          <h2>🎉 Premium Content Unlocked!</h2>
          <p>Thank you for your payment.</p>
        </div>
      )}
    </div>
  );
}
