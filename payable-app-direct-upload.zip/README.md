# Payable App
A simple React app with paywall functionality.
